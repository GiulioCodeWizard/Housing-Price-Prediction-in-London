############################
XGBoost Command Line version
############################

See `XGBoost Command Line walkthrough <https://github.com/dmlc/xgboost/tree/master/demo/CLI/binary_classification>`_.
