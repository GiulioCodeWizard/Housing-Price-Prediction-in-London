#############
Release Notes
#############

For release notes prior to the 2.1 release, please see `news <https://github.com/dmlc/xgboost/blob/master/NEWS.md>`__ .

.. toctree::
  :maxdepth: 1
  :caption: Contents:

  v2.1.0