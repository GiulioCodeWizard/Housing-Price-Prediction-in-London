Survival Analysis Walkthrough
=============================

This is a collection of examples for using the XGBoost Python package for training
survival models. For an introduction, see :doc:`/tutorials/aft_survival_analysis`
