.. _dask-examples:

XGBoost Dask Feature Walkthrough
================================

This directory contains some demonstrations for using `dask` with `XGBoost`.  For an
overview, see :doc:`/tutorials/dask`
