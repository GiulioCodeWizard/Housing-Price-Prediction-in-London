"""
Dajani Giulio 001343717
AI Coursework - COMP1827
Model Training Data File
"""

import xgboost as xgb  # XGBoost library for advanced model training
from scripts.preprocessing import preprocess_data, log
from sklearn.model_selection import train_test_split  # Used for splitting the dataset into training and testing sets
from sklearn.metrics import r2_score  # Used for evaluating the expected vs target performance


def features_encoding(features):
    for col in ['code', 'area']:
        if col in features.columns:
            features[col] = features[col].astype('category').cat.codes  # converting columns 'code' & 'area' into
            # category data type assigning each of them a unique integer code. ex. [A, B, C] => [0, 1, 2]

    features = features.drop(columns=['date'])  # remove original column date so, we can use the year, month, day
    # columns instead that are numeric values and so can be handled by XGBoost Training Model

    return features


def train_model():
    # Train advanced model in 6 steps:
    # 1) Data loading
    # 2) Features & Target preparation
    # 3) Dataset splitting
    # 4) Model training
    # 5) Model evaluation
    # 6) Future use save
    log.info('Model training started')

    # 1) Data loading
    input_path = '../dataset/housing_in_london_yearly_variables.csv'
    data = preprocess_data(input_path)

    # 2) Features & Target preparation
    target_column = 'avg_house_price'
    features = data.drop(columns=[target_column])
    target = data[target_column]

    features = features_encoding(features)

    # Checking if dataset contains NULL values
    missing_count_features = features.isnull().sum().sum()
    missing_count_target = target.isnull().sum()
    if missing_count_features > 0 or missing_count_target > 0:
        log.error('Dataset contains NULL values')
        raise ValueError('Dataset contains NULL values')
    else:
        log.info('Dataset [OK]')

    # 3) Dataset splitting [train:test = 84:16]
    x_train, x_test, y_train, y_test = train_test_split(features, target, test_size=0.16, random_state=47)

    # 4) Model training [DMtrain & DMtest are XGBoost's internal data structures that store the data and labels]
    DMtrain = xgb.DMatrix(x_train, label=y_train)
    DMtest = xgb.DMatrix(x_test, label=y_test)

    parameters = {
        # Using tested parameters for better accuracy using RMSE as the standard eval metric
        "objective": "reg:squarederror",
        "seed": 50,
        "learning_rate": 0.0772,
        "max_depth": 7,
        "subsample": 0.8,
        "gamma": 0.001,
        "reg_alpha": 0.001,
        "reg_lambda": 0.001
    }

    log.info('Training the XGBoost model...')
    BST = xgb.train(parameters, DMtrain, num_boost_round=100)

    # 5) Model evaluation [Making predictions using the trained model and calculating the accuracy]
    predictions = BST.predict(DMtest)
    error_tolerance = 0.05
    R2 = r2_score(y_test, predictions)
    total_predictions = len(y_test)
    errors = abs(y_test - predictions) / y_test
    correct_predictions = (errors <= error_tolerance).sum()
    accuracy = correct_predictions / total_predictions

    log.info('Model Evaluation Training: ')
    log.info(f"Expected vs Target performance [R2 Score]: {R2:.5f}")  # expected vs target performance
    log.info(f"Total predictions: {total_predictions}")
    log.info(f"Correct predictions: {correct_predictions}")
    log.info(f"Accuracy of the model is {accuracy * 100:.2f}% based on a {error_tolerance * 100}% acceptable error "
             f"tolerance")

    # 6) Future use save [Saving the trained model as an ubj script for future deployment in app.py]
    model_path = '../outputs/model/model.ubj'
    BST.save_model(model_path)
    log.info(f"Model saved to {model_path}")

    log.info('Model training finished')
    log.info('--------------------------------------------------------------------')

    return BST, y_test, predictions
