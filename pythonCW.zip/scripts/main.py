"""
Dajani Giulio 001343717
AI Coursework - COMP1827
Main File
"""

from scripts.preprocessing import preprocess_data
from scripts.validation import validate_data
from scripts.testing import main as testing_data
from scripts.model import train_model
from scripts.visualisation import visualise_data
# from scripts.app import app
# from scripts.request import main as request_data


def main():
    input_path = '../dataset/housing_in_london_yearly_variables.csv'
    cleaned_path = '../outputs/data/cleaned_data.csv'
    log_path = '../outputs/log/stepsInfo.log'

    preprocess_data(input_path)
    validate_data(input_path, cleaned_path, log_path)
    testing_data()
    BST, y_test, predictions = train_model()
    visualise_data(BST, y_test, predictions)
    # app.run(debug=True)
    # request_data()


if __name__ == "__main__":
    main()
