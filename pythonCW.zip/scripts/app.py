"""
Dajani Giulio 001343717
AI Coursework - COMP1827
Model Deployment Data File
"""

""" Just Started. It needs to be fixed """

from model import xgb
from flask import Flask, request, jsonify  # Library used to load Flask and jsonify for API creation and handling
# requests in JSON format


app = Flask('Housing Price Prediction API')

# Loading the trained model from the file into memory
model = xgb.Booster()
model.load_model('../outputs/model/model.ubj')

# API endpoint accepting JSON data and returning the predicted average house price
@app.route('/predict', methods=['POST'])
def predict():
    data = request.get_json()

    dMatrix = xgb.DMatrix([[
        data['code'], data['area'], data['median_salary'], data['life_satisfaction'], data['mean_salary'],
        data['recycling_pct'], data['population_size'], data['number_of_jobs'], data['area_size'], data['no_of_houses'],
        data['borough_flag'], data['year'], data['month'], data['day'],data['avg_house_price'],
        data['price_to_income_ratio'], data['relative_house_price'], data['income_per_job'],
        data['price_income_interaction']
    ]])

    prediction = model.predict(dMatrix)

    return jsonify({'avg_house_price': prediction[0]})

if __name__ == '__main__':
    app.run(debug=True)
