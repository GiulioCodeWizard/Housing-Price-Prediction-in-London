"""
Dajani Giulio 001343717
AI Coursework - COMP1827
Visualisation Data File
"""

from scripts.model import xgb, log
import matplotlib.pyplot as plt  # Library used for plotting


def visualise_data(BST, y_test, predictions):
    log.info('Visualisation started')

    # Plotting feature importance and saving it to the file specified in the 'outputs' directory
    fig, ax = plt.subplots(figsize=(15, 6))
    xgb.plot_importance(BST, ax=ax)
    plt.title("Feature Importance", fontsize=16, fontweight="bold")
    plt.xlabel("Feature Score", fontsize=14)
    plt.ylabel("Features", fontsize=14)
    plt.grid(True, linestyle='--', alpha=0.5)
    feature_importance_path = '../outputs/img/FeatureImportance.png'
    plt.savefig(feature_importance_path, bbox_inches="tight")
    log.info(f"Feature Importance plot saved at {feature_importance_path}")
    plt.show()

    # Plotting actual vs predicted values and saving it to the file specified in the 'outputs' directory
    plt.scatter(y_test, predictions, alpha=0.5)
    plt.title("Actual vs Predicted Values", fontsize=16, fontweight="bold")
    plt.xlabel("Actual Values", fontsize=14)
    plt.ylabel("Predicted Values", fontsize=14)
    plt.grid(True, linestyle='--', alpha=0.5)
    actual_VS_predicted_path = "../outputs/img/actual_VS_predicted.png"
    plt.savefig(actual_VS_predicted_path, bbox_inches="tight")
    log.info(f"Actual VS Predicted plot saved at {actual_VS_predicted_path}")
    plt.show()

    log.info('Visualisation finished')
    log.info('====================================================================')
    log.info('Deployment of the API is not implemented yet')
    log.info('====================================================================')
