"""
Dajani Giulio 001343717
AI Coursework - COMP1827
Preprocessing Data File
"""

import pandas as pd  # CSV reading and manipulation library
import logging as log  # Create text file with steps information


def preprocess_data(data_path):  # Preprocess the dataset by performing data cleaning &
    # feature engineering. Take the path to the CSV file as input and returns the preprocessed dataset
    data = pd.read_csv(data_path)

    # Initialising logging and saving any updates in the stepsInfo.log file in the outputs folder
    log.basicConfig(filename='../outputs/log/stepsInfo.log', level=log.INFO, filemode='w',
                    format='%(name)s - %(asctime)s - %(levelname)s - %(message)s')
    log.info('Preprocessing started')

    required_columns = ['code', 'area', 'date']  # Example of some required columns used in testing.py
    for col in required_columns:
        if col not in data.columns:
            log.error(f"The dataset is missing one or more expected columns: {col}")
            raise ValueError(f"The dataset is missing one or more expected columns: {col}")

    data['date'] = pd.to_datetime(data['date'], errors='coerce')  # Converting date to datetime and handling missing
    # values
    data['mean_salary'] = pd.to_numeric(data['mean_salary'], errors='coerce')  # Converting to numeric if it's not
    data['recycling_pct'] = data['recycling_pct'].astype(str)  # Converting to string if it's not for testing.py file
    # Converting percentage to decimal handling missing and non-numeric values
    data['recycling_pct'] = data['recycling_pct'].str.rstrip('%').replace(['na', 'NA', ''], None).astype(float) / 100

    log.info(f"Data shape after initial transformations => {data.shape}")  # starting shape [rows x columns]

    # Handling missing values & Data type
    numeric_columns = data.select_dtypes(include=['float64', 'int64']).columns
    data[numeric_columns] = data[numeric_columns].fillna(data[numeric_columns].median())
    columns_to_convert = ['population_size', 'number_of_jobs', 'no_of_houses']
    data[columns_to_convert] = data[columns_to_convert].fillna(0).astype('int64')

    # Feature engineering [creating new columns for better accuracy]
    data['year'] = data['date'].dt.year
    data['month'] = data['date'].dt.month
    data['day'] = data['date'].dt.day

    # Creating avg_house_price column data using a weighted formula based on a combination of 5 features:
    # 1) Median Salary => Often areas with higher salaries have higher house prices
    # 2) Population Size => Usually there's an increase of house demanding with larger populations, affecting prices
    # 3) Number of Houses => Fewer houses in a particular zone relative to population might increase prices
    # 4) Area Size => Smaller areas might have higher prices due to limited space
    # 5) Borough Flag => If an area is a borough significantly affects housing prices

    # Formula for "calculating" the average house price => avg_house_price=(median_salary×W1)+(population_size×W2)+(
    # no_of_houses×W3)−(area_size×W4)+(borough_flag×W5), where Wn is the most appropriate weight decided through testing
    data['avg_house_price'] = (
            data['median_salary'] * 1.0 +
            data['population_size'] * 0.5 +
            data['no_of_houses'] * 0.2 +
            data['area_size'] * (-0.3) +  # Larger areas might reduce prices so, I multiply for a negative coefficient
            data['borough_flag'] * 1.5
    )

    # Creating new features based on the calculated avg_house_price rounded up to 4 decimal places for better accuracy
    data['price_to_income_ratio'] = round(data['avg_house_price'] / data['median_salary'], 4)
    data['relative_house_price'] = round(data['avg_house_price'] / max(data['avg_house_price']), 4)
    data['income_per_job'] = round(data['median_salary'] / data['number_of_jobs'], 4)
    data['price_income_interaction'] = round(data['avg_house_price'] * (data['median_salary'] /
                                                                        data['population_size']), 4)

    # Histogram showing the distribution of 'Relative House Price x Number of Areas'
    histo = data['relative_house_price'].hist(label='Relative House Price x Number of Areas', bins=35, alpha=0.85)
    histo.get_figure().set_size_inches(10, 8)
    histo.set_title('Relative House Prices x Number of Areas', fontsize=16, fontweight='bold')
    histo.set_xlabel('Relative House Price', fontsize=14)
    histo.set_ylabel('Number of Areas', fontsize=14)

    # Saving cleaned data in the outputs folder
    data.to_csv('../outputs/data/cleaned_data.csv', index=False)
    log.info('Cleaned data saved')
    log.info('--------------------------------------------------------------------')

    return data
