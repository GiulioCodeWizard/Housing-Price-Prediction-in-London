"""
Dajani Giulio 001343717
AI Coursework - COMP1827
Testing Data File
"""

import pytest  # Library for testing purposes
import numpy as np  # Library for numerical operations
from scripts.preprocessing import preprocess_data, pd, log
from scripts.validation import validate_data


@pytest.fixture
def correct_data():  # Testing with correct dataset
    data = {
        'code': ['E09000001', 'E09000028', 'K02000001'],
        'area': ['greenwich', 'haringey', 'westminster'],
        'date': ['2001-12-01', '2003-12-01', '2015-12-01'],
        'median_salary': [30591.0, 38147.0, 42153.0],
        'life_satisfaction': [7.69, 7.88, 7.6],
        'mean_salary': [45644.0, 29804.0, 82808.0],
        'recycling_pct': [0.53, 0.14, 0.23],
        'population_size': [60413276, 181508, 7131],
        'number_of_jobs': [96000, 27147000, 35547000],
        'area_size': [315.0, 13303728.0, 8675.0],
        'no_of_houses': [22072566, 22287502, 133673],
        'borough_flag': [0, 0, 1],
    }

    log.info('Correct dataset ready to use for testing')
    return pd.DataFrame(data)


@pytest.fixture
def wrong_data():  # Testing with wrong dataset
    data = {
        'code': ['E09000007', 'E090000018', None],
        'area': ['redbridge', None, 'wandsworth'],
        'date': ['2013-12-01', None, '2018-12-01'],
        'median_salary': [33163.0, np.nan, 49237.0],
        'life_satisfaction': [7.7, 7.84, None],
        'mean_salary': [37030.0, '<null>', 'not_a_number'],
        'recycling_pct': [0.4, 'NA', 'null'],
        'population_size': [66435550, 8072, None],
        'number_of_jobs': ['<null>', np.nan, 89000],
        'area_size': [11446.0, 159471.0, None],
        'no_of_houses': [21684360, 'NaN', '<null>'],
        'borough_flag': [1, 0, None],
    }

    log.info('Wrong dataset ready to use for testing')
    return pd.DataFrame(data)


def test_preprocess_data(correct_data):  # Testing preprocess_data function with a valid dataset
    correct_file_path = '../outputs/data/correct_data.csv'  # Original data [path]
    cleaned_data_path = '../outputs/data/cleaned_data.csv'  # Cleaned data [path]

    correct_data.to_csv(correct_file_path, index=False)
    preprocess_data(correct_file_path)

    try:
        cleaned_data = pd.read_csv(cleaned_data_path)
    except FileNotFoundError:
        log.error(f"Cleaned data file not found: {cleaned_data_path}")
        return  # If the file is missing the testing process finishes here

    # Checking if the required columns exist in the cleaned data
    exp_cols = ['avg_house_price','price_to_income_ratio', 'relative_house_price', 'income_per_job',
                'price_income_interaction']
    for col in exp_cols:
        if col not in cleaned_data.columns:
            log.error(f"'{col}' column missing")
        else:
            log.info(f"'{col}' column exists")

    # Checking for missing values in the cleaned data
    missing_count = cleaned_data.isnull().sum().sum()
    if missing_count > 0:
        log.error('Cleaned data contains NULL values')
    else:
        log.info('Cleaned data has no NULL values')

    log.info("Testing 'preprocess_data' function with a valid dataset successfully completed")


def test_preprocess_data_malformed(wrong_data):  # Testing preprocess_data function with a wrong dataset
    incorrect_file_path = '../outputs/data/wrong_data.csv'  # Wrong data [path]
    cleaned_data_path = '../outputs/data/cleaned_data.csv'  # Cleaned data [path]

    wrong_data.to_csv(incorrect_file_path, index=False)

    try:
        preprocess_data(incorrect_file_path)
        try:
            pd.read_csv(cleaned_data_path)
            log.error("Cleaned data wasn't supposed to be generated")
        except FileNotFoundError:
            log.info('Cleaned data file was not created, as expected')
            return
    except Exception as e:
        log.error(f"Error during preprocessing: {e}")
        log.info("Testing 'preprocess_data' function with a wrong dataset successfully completed")


def test_validate_data(correct_data):  # Testing validate_data function with valid data
    input_path = '../outputs/data/input_data.csv'  # Original data [path]
    cleaned_path = '../outputs/data/cleaned_data.csv'  # Cleaned data [path]
    log_path = '../outputs/log/stepsInfo.log'  # Log file [path]

    correct_data.to_csv(input_path, index=False)
    preprocess_data(input_path)

    try:
        validate_data(input_path, cleaned_path, log_path)
        log.info("'validate_data' function executed successfully with the valid dataset")
    except Exception as e:
        log.error(f"Error during validation: {e}")

    log.info("Testing 'validate_data' function with a valid dataset successfully completed")


def test_validate_data_missing_columns(correct_data):  # Testing validate_data function with missing columns
    input_path = '../outputs/data/input_data_missing_columns.csv'  # Modified input data [path]

    # Modifying the valid dataset & removing some required columns
    modified_data = correct_data.drop(columns=['code', 'area', 'date'])
    modified_data.to_csv(input_path, index=False)

    # Attempting to preprocess the data, expecting of course a failure during data loading
    error = 'missing one or more expected columns'
    try:
        preprocess_data(input_path)
        log.error('Preprocessing should have failed due to missing columns')
    except ValueError as e:
        if error in str(e):
            log.info('Preprocessing failed as expected due to missing columns')
        else:
            log.error(f"Unexpected error during preprocessing: {e}")

    log.info("Testing 'validate_data' function with missing columns successfully completed")


def test_edge_case_empty_dataset():  # Testing preprocess_data function with an empty dataset
    file_path = '../outputs/data/empty_data.csv'  # Empty data [path]

    empty_data = pd.DataFrame()
    empty_data.to_csv(file_path, index=False)

    # Running preprocess_data and expecting it to raise a ValueError due to empty dataset
    error_message = 'No data to process'
    try:
        preprocess_data(file_path)
        log.error('Preprocessing should have failed due to empty dataset')
    except ValueError as e:
        if error_message in str(e):
            log.info('Preprocessing failed as expected due to empty dataset')
        else:
            log.error(f"Unexpected error during preprocessing: {e}")

    log.info("Testing 'preprocess_data' function with an empty dataset successfully completed")


def test_edge_case_single_row_dataset():  # Testing preprocess_data function with a single-row dataset
    file_path = '../outputs/data/single_row_data.csv'  # Single-row data [path]

    # Creating a single-row dataset
    single_row_data = pd.DataFrame({
        'code': ['K02000001'],
        'area': ['westminster'],
        'date': ['2015-12-01'],
        'median_salary': [42153.0],
        'life_satisfaction': [7.6],
        'mean_salary': [82808.0],
        'recycling_pct': [0.0023],
        'population_size': [7131],
        'number_of_jobs': [35547000],
        'area_size': [8675.0],
        'no_of_houses': [133673],
        'borough_flag': [1],
    })

    single_row_data.to_csv(file_path, index=False)

    try:
        preprocess_data(file_path)
        cleaned_data_path = '../outputs/data/cleaned_data.csv'
        cleaned_data = pd.read_csv(cleaned_data_path)

        # Checking if the cleaned data has the expected shape (single row x columns)
        if cleaned_data.shape[0] != 1:
            print('Cleaned data should have one row')

        exp_output_columns = [
            'code', 'area', 'date', 'median_salary',
            'life_satisfaction', 'mean_salary', 'recycling_pct', 'population_size',
            'number_of_jobs', 'area_size', 'no_of_houses', 'borough_flag',
            'year', 'month', 'day', 'avg_house_price',
            'price_to_income_ratio', 'relative_house_price', 'income_per_job', 'price_income_interaction'
        ]

        # Checking if the cleaned data has the expected columns
        for col in exp_output_columns:
            if col not in cleaned_data.columns:
                log.error(f"Cleaned data is missing the '{col}' column")
                raise ValueError('Cleaned data is missing one or more expected columns')
        log.info('Preprocessing completed successfully for a single-row dataset')

    except Exception as e:
        log.error(f"Unexpected error during preprocessing of a single-row dataset: {e}")
        raise

    log.info("Testing 'preprocess_data' function with a single-row dataset successfully completed")


def test_large_dataset():  # Testing preprocess_data function with a very large dataset
    file_path = '../outputs/data/very_large_data.csv'  # Large dataset [path]

    # Creating a large dataset with 100,000 rows
    large_data = pd.DataFrame({
        'code': [f'E09000001'] * 100_000,
        'area': [f'city of london'] * 100_000,
        'date': ['2019-12-01'] * 100_000,
        'median_salary': np.random.randint(25_000, 100_000, 100_000),
        'life_satisfaction': np.random.uniform(4.0, 9.5, 100_000),
        'mean_salary': np.random.randint(25_000, 100_000, 100_000),
        'recycling_pct': [0.5] * 100_000,
        'population_size': np.random.randint(10_000, 500_000, 100_000),
        'number_of_jobs': np.random.randint(1000, 1_000_000, 100_000),
        'area_size': np.random.uniform(50.0, 500.0, 100_000),
        'no_of_houses': np.random.randint(5000, 100_000, 100_000),
        'borough_flag': [1] * 100_000,
    })

    large_data.to_csv(file_path, index=False)

    try:
        preprocess_data(file_path)
        cleaned_data_path = '../outputs/data/cleaned_data.csv'
        cleaned_data = pd.read_csv(cleaned_data_path)

        # Checking if the cleaned data has the expected shape (100,000 rows x columns)
        if cleaned_data.shape[0] != 100_000:
            print('Cleaned data should have 100,000 rows')

        exp_output_columns = [
            'code', 'area', 'date', 'median_salary',
            'life_satisfaction', 'mean_salary', 'recycling_pct', 'population_size',
            'number_of_jobs', 'area_size', 'no_of_houses', 'borough_flag',
            'year', 'month', 'day', 'avg_house_price',
            'price_to_income_ratio', 'relative_house_price', 'income_per_job', 'price_income_interaction'
        ]

        # Checking if the cleaned data has the expected columns
        for col in exp_output_columns:
            if col not in cleaned_data.columns:
                log.error(f"Cleaned data is missing the '{col}' column")
                raise ValueError('Cleaned data is missing one or more expected columns')

        missing_count = cleaned_data.isnull().sum().sum()
        if missing_count > 0:
            log.error('Cleaned data contains NULL values')
        else:
            log.info('Cleaned data has no NULL values')

        log.info('Preprocessing completed successfully for a very large dataset with 100,000 rows')

    except Exception as e:
        log.error(f"Unexpected error during preprocessing of a very large dataset: {e}")
        raise

    log.info("Testing 'preprocess_data' function with a very large dataset successfully completed")


def main():
    log.info('Testing started')

    log.info('Running tests...')
    # Running all tests one-by-one until everything passes or a failure occurs
    result = pytest.main(['testing.py', '-v', '--disable-warnings'])
    if result != 0:
        log.error('Some tests failed...please try again')
    else:
        log.info('All tests passed successfully')

    log.info('Testing finished')
    log.info('--------------------------------------------------------------------')
