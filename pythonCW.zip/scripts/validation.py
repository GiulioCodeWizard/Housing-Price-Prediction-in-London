"""
Dajani Giulio 001343717
AI Coursework - COMP1827
Validation Data File
"""

from scripts.preprocessing import pd, log


def validate_data(input_path, cleaned_path, log_path):
    # Validates preprocessing data in 5 steps:
    # 1) Data loading & info
    # 2) Data transformations
    # 3) Missing value handling
    # 4) Feature engineering
    # 5) File outputs
    log.info('Validation started')

    # 1) Data loading & info
    try:
        og_data = pd.read_csv(input_path)
        cleaned_data = pd.read_csv(cleaned_path, parse_dates=['date'])
        # Information about preprocessed cleaned data
        print('================================== information ==================================')
        print(cleaned_data.info())
        print('===================================== head ======================================')
        print(cleaned_data.head())
        print('=================================== describe ====================================')
        print(cleaned_data.describe())
    except FileNotFoundError as e:
        log.error(f"File not found: {e}")
        raise
    except Exception as e:
        log.error(f"An error occurred while loading data: {e}")
        raise

    log.info(f"Original data shape: {og_data.shape}")
    log.info(f"Cleaned data shape: {cleaned_data.shape}")

    try:
        exp_output_columns = [
            'code', 'area', 'date', 'median_salary',
            'life_satisfaction', 'mean_salary', 'recycling_pct', 'population_size',
            'number_of_jobs', 'area_size', 'no_of_houses', 'borough_flag',
            'year', 'month', 'day', 'avg_house_price',
            'price_to_income_ratio', 'relative_house_price', 'income_per_job', 'price_income_interaction'
        ]
        # Check if all expected columns are present in the cleaned data
        for col in exp_output_columns:
            if col not in cleaned_data.columns:
                log.error(f"Cleaned data is missing the '{col}' column")
                raise ValueError('Cleaned data is missing one or more expected columns')
        log.info('All expected columns are present in the cleaned data')

        # 2) Data transformations [ensure date and numeric columns are correctly converted]
        if not pd.api.types.is_datetime64_any_dtype(cleaned_data['date']):
            log.error("The conversion of the 'date' column from object to datetime was not successfully completed")
            raise ValueError('Date conversion failed')
        else:
            log.info('Date conversion successful')

        if not pd.api.types.is_numeric_dtype(cleaned_data['mean_salary']):
            log.error("The conversion of the 'mean_salary' column from object to numeric was not successfully completed")
            raise ValueError('Mean salary conversion failed')
        else:
            log.info('Mean salary conversion successful')

        if not pd.api.types.is_float_dtype(cleaned_data['recycling_pct']):
            log.error("The conversion of the 'recycling_pct' column from object to float was not successfully completed")
            raise ValueError('Recycling % conversion failed')
        else:
            log.info('Recycling percentage conversion successful')

        int_type_columns = ['population_size', 'number_of_jobs', 'no_of_houses']
        for col in int_type_columns:
            if not pd.api.types.is_integer_dtype(cleaned_data[col]):
                log.error(f"The conversion of the column '{col}' from float to int was not successfully completed")
                raise ValueError(f"The '{col}' column is not of integer type")
            else:
                log.info(f"The conversion of the '{col}' column into integer type has successfully been completed")

        # 3) Missing value handling
        missing_count = cleaned_data.isnull().sum().sum()
        if missing_count > 0:
            log.info(f"NULL values found in cleaned data: {missing_count} missing values.")
            raise ValueError('Cleaned data contains NULL values [preprocessing issue]')
        else:
            log.info('Missing value handling validation passed: No NULL values found')

        # 4) Feature engineering [validation with avg_house_price columns data creation]
        for price in cleaned_data['avg_house_price']:
            if price < 0:
                log.error("There are invalid negative values in 'avg_house_price'")
                raise ValueError("Invalid values in 'avg_house_price' column")
        log.info('Feature engineering validation passed: No invalid values found')

        # 5) File outputs
        try:
            # Check if the files exist, opening them in read mode and counting the number of rows
            with open(cleaned_path, 'r') as f:
                count = 0
                for _ in f:
                    count += 1
            log.info(f"Cleaned data file successfully found at {cleaned_path} and it contains {count} rows")
            with open(log_path, 'r') as f:
                count = 0
                for _ in f:
                    count += 1
            log.info(f"Log file successfully found at {log_path} and it contains {count} rows")
        except Exception as e:
            log.error(f"File validation failed: {e}")
            raise
    except AssertionError as e:
        log.error(f"Validation failed: {e}")
        raise
    except Exception as e:
        log.error(f"Unexpected error during validation: {e}")
        raise

    log.info('Validation finished')
    log.info('--------------------------------------------------------------------')
