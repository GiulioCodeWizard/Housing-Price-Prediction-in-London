"""
Dajani Giulio 001343717
AI Coursework - COMP1827
HTTP Request Data File
"""

""" Just Started. It needs to be fixed """

import requests  # Library used for making HTTP requests

# Sending a POST request to the API endpoint
def main():
    payload = {
        'code': 'E09000033', 'area': 'westminster', 'median_salary': 42_153.0, 'life_satisfaction': 7.6,
        'mean_salary': 82_808.0, 'recycling_pct': 0.0023, 'population_size': 7131, 'number_of_jobs': 35_547_000,
        'area_size': 8675.0, 'no_of_houses': 133_673, 'borough_flag': 1, 'year': 2018, 'month': 12, 'day': 1,
        'avg_house_price': 230_000, 'price_to_income_ratio': 7.64, 'relative_house_price': 0.85, 'income_per_job': 2.5,
        'price_income_interaction': 106.25
    }

    try:
        response = requests.post('http://127.0.0.1:5000/predict', json=payload)
        print(f"Response: {response.json()}")
    except requests.exceptions.RequestException as e:
        print(f"Error: {e}")


if __name__ == "__main__":
    main()
